'use strict';

module.exports = function(Ideiaexperimento) {

};
