'use strict';

module.exports = function(Cotacaodiarioacao) {

};
