'use strict';

module.exports = function(Regrasimulacao) {

};
