'use strict';

module.exports = function(Startupinvestimento) {

};
