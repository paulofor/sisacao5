'use strict';

module.exports = function (Cdb) {


    /**
 * 
 * @param {object} saida 
 * @param {Function(Error, object)} callback
 */

    Cdb.InsereSeNaoExisteCDB = function (item, callback) {
        var resultado;
        // TODO
        callback(null, resultado);
    };


};
