'use strict';

module.exports = function(Ativoimobiliario) {

};
