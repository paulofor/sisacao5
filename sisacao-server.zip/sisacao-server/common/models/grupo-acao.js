'use strict';

module.exports = function(Grupoacao) {

};
