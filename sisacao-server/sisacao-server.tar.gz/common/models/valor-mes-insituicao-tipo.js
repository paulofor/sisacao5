'use strict';

module.exports = function(Valormesinsituicaotipo) {

};
