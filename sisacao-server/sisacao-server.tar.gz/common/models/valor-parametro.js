'use strict';

module.exports = function(Valorparametro) {

};
