'use strict';

module.exports = function(Cotacaodiarioindice) {

};
