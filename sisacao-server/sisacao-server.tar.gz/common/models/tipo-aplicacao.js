'use strict';

module.exports = function(Tipoaplicacao) {

};
