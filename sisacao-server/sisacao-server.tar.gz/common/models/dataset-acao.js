'use strict';

module.exports = function(Datasetacao) {

};
