'use strict';

module.exports = function(Startupfundo) {

};
