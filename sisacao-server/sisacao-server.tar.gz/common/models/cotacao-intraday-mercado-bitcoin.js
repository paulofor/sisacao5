'use strict';

module.exports = function(Cotacaointradaymercadobitcoin) {

};
