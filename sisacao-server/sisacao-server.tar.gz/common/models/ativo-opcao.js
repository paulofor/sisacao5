'use strict';

module.exports = function(Ativoopcao) {

};
