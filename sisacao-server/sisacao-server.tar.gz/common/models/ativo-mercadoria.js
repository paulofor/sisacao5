'use strict';

module.exports = function(Ativomercadoria) {

};
