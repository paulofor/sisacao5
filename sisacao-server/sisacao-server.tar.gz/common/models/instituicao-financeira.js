'use strict';

module.exports = function(Instituicaofinanceira) {

};
