'use strict';

module.exports = function(Atributodataset) {

};
