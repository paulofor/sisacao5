'use strict';

module.exports = function(Ativo) {

};
