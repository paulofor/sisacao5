'use strict';

module.exports = function(Ativoindice) {

};
