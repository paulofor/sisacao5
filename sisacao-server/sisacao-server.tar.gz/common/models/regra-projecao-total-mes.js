'use strict';

module.exports = function(Regraprojecaototalmes) {

};
