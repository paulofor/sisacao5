'use strict';

module.exports = function(Exemplotreinoacao) {

};
