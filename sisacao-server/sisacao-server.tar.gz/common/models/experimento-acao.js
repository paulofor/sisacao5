'use strict';

module.exports = function(Experimentoacao) {

};
