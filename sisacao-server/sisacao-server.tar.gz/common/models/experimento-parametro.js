'use strict';

module.exports = function(Experimentoparametro) {

};
