'use strict';

module.exports = function(Aplicacaoinstituicao) {



  
};
