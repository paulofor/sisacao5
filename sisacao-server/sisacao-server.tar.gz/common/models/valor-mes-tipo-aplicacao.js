'use strict';

module.exports = function(Valormestipoaplicacao) {

};
