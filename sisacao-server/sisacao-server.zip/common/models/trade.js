'use strict';

module.exports = function(Trade) {

};
