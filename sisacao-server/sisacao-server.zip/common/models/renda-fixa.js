'use strict';

module.exports = function (Rendafixa) {


    /**
    * 
    * @param {array} listaItem 
    * @param {Function(Error, object)} callback
    */
    Rendafixa.InsereSeNaoExisteFixa = function (listaItem, callback) {
        var resultado;
        // TODO
        callback(null, resultado);
    };

};
