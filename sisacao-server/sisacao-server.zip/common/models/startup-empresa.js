'use strict';

module.exports = function(Startupempresa) {

};
