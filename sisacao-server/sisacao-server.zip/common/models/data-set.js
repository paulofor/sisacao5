'use strict';

module.exports = function(Dataset) {

};
