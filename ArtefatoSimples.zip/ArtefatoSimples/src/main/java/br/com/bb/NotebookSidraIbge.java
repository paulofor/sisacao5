package br.com.bb;

import org.json.JSONArray;

public class NotebookSidraIbge extends NotebookObj {

	@Override
	protected void montaScript(JSONArray notebook) {
		// TODO Auto-generated method stub
		
	}

}
