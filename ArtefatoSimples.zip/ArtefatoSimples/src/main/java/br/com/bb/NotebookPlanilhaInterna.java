package br.com.bb;

import org.json.JSONArray;

public class NotebookPlanilhaInterna extends NotebookObj{

	@Override
	protected void montaScript(JSONArray notebook) {
		// TODO Auto-generated method stub
		
	}

	

}
