package br.com.bb;

import org.json.JSONObject;

public class NotebookJson {
	private JSONObject json;
	
	public NotebookJson() {
		json = new JSONObject();
	}
}
