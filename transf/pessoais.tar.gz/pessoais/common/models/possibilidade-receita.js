'use strict';

module.exports = function(Possibilidadereceita) {

};
