'use strict';

module.exports = function(Rendapassivaprojeto) {

};
