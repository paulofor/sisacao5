'use strict';

module.exports = function(Oportunidademacroeconomica) {

};
