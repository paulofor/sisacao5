'use strict';

module.exports = function(Gerprojsistemacrenca) {

};
