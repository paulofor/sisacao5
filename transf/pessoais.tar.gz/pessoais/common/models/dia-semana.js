'use strict';

module.exports = function(Diasemana) {

};
