'use strict';

module.exports = function(Gerprojobjetivoresultado) {

};
