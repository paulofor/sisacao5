'use strict';

module.exports = function (Ctrlfinconta) {

    /**
 * 
 * @param {Function(Error)} callback
 */

    Ctrlfinconta.TesteAtualizacao = function (callback) {
        // TODO
        callback(null);
    };

};
