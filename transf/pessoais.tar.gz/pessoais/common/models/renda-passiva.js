'use strict';

module.exports = function(Rendapassiva) {

};
