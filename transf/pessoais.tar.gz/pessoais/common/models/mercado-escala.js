'use strict';

module.exports = function(Mercadoescala) {

};
