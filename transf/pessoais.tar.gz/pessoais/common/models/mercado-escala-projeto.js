'use strict';

module.exports = function(Mercadoescalaprojeto) {

};
