'use strict';

module.exports = function(Gerprojgrupoprojeto) {

};
