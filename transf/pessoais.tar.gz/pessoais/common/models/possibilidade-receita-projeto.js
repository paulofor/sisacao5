'use strict';

module.exports = function(Possibilidadereceitaprojeto) {

};
